package com.mercendayzer.app;
import android.app.Activity;
import android.os.Bundle;
import android.Manifest;
import android.webkit.*;

public class MainActivity extends Activity {
    WebView w;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(android.os.Build.VERSION.SDK_INT>=23)
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.CAMERA},100);
        w=new WebView(this); setContentView(w);
        WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setGeolocationEnabled(true);
        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient(){
            @Override public void onGeolocationPermissionsShowPrompt(String o, GeolocationPermissions.Callback c){c.invoke(o,true,false);}
        });
        w.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed(){ if(w.canGoBack()) w.goBack(); else super.onBackPressed(); }
}
